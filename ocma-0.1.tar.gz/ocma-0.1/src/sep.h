#ifndef __SEP_H__
#define __SEP_H__

int sep(int argc, char *argv[]);

#endif