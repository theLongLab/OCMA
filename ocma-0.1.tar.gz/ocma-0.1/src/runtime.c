#include<stdio.h>
#include<time.h>
#include<sys/time.h>
#include<stdlib.h>

void print_runtime() 
{
	static int first = 1;
	static struct timeval starttime, endtime;
	double interval_seconds = 0;
	double interval_hours = 0;
		
	if (first == 1) {
		first = 0;
		gettimeofday(&starttime,NULL);
		printf("=== begin to record time ===\n");
		return;
	}
	
	gettimeofday(&endtime,NULL);
	interval_seconds = (endtime.tv_sec - starttime.tv_sec) + ((double)(endtime.tv_usec - starttime.tv_usec))/1000000;
	interval_hours = interval_seconds / 3600;
	
	printf("=== runtime = %.1f seconds ===", interval_seconds);
	printf("  ||  ");
	printf("=== runtime = %.2f hours ===\n", interval_hours);
}