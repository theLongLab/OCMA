#include <stdlib.h>
#include <stdio.h>
#include <math.h>

#include <sys/mman.h> /* for mmap and munmap */
#include <sys/types.h> /* for open */
#include <sys/stat.h> /* for open */
#include <fcntl.h>     /* for open */
#include <unistd.h>    /* for lseek and write */

#define PRINT_LIMIT 5

void create_file(char *name, size_t len)
{
	FILE *fp;
	float f = 0;
	fp = fopen(name, "w+");
	fseek(fp, len-sizeof(float), SEEK_END);
	fwrite(&f, sizeof(float), 1, fp);
	fclose(fp);
}

///////////////////////////////////////////////////////////////////////////
//vector

float *open_vector_file(long n, char *name)
{
	int fd;
	float *data;
	void *start_addr = 0;
	
	fd = open(name, O_RDWR | O_CREAT, S_IRUSR | S_IWUSR);	
	data = (float *)mmap(start_addr, n*sizeof(float), PROT_READ|PROT_WRITE, MAP_SHARED, fd, 0);
	
	return data;
}


void free_vector(float *data, long n)
{
	munmap(data, n*sizeof(float));
	//do not close file
}

void print_vector(float *data, long n)
{
	long j;
	
	if (n <= 2*PRINT_LIMIT) {
		for (j=0; j<n; j++) {
			printf("%+e ", data[j]);
		}			
		printf("\n");		
		return;
	}
	
	//else
	for (j=0; j<PRINT_LIMIT; j++) {
		printf("%+e ", data[j]);
	}	
	printf("... ");
	for (j=n-PRINT_LIMIT; j<n; j++) {
		printf("%+e ", data[j]);
	}
	printf("\n");  
}

///////////////////////////////////////////////////////////////////////////
//matrix

float *open_matrix_file(long m, long n, char *name)
{
	int fd;
	float *data;
	void *start_addr = 0;
	long mn = (long)m * (long)n;
	
	fd = open(name, O_RDWR | O_CREAT, S_IRUSR | S_IWUSR);	
	data = (float *)mmap(start_addr, mn*sizeof(float), PROT_READ|PROT_WRITE, MAP_SHARED, fd, 0);
		
	return data;
}


void free_matrix(float *data, long m, long n)
{
	munmap(data, m*n*sizeof(float));
	//do not close file
}

void print_matrix(float *data, long m, long n)
{
	long i;
	long in;
	
	if (m <= 2*PRINT_LIMIT) {
		for (i=0; i<m; i++) {
			print_vector(&data[i*n], n);
		}			
		return;
	}
	
	//else
	for (i=0; i<PRINT_LIMIT; i++) {
		in = (long)i * (long)n;
		print_vector(&data[in], n);
	}	
	printf("...\n");
	for (i=m-PRINT_LIMIT; i<m; i++) {
		in = (long)i * (long)n;
		print_vector(&data[in], n);
	}
}