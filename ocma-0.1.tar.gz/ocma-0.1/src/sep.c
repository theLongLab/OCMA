#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <memory.h>
#include <math.h>

#include "mkl.h"

#include "runtime.h"
#include "matrixfile.h"

#define FLAG_DISK 		0
#define FLAG_MEMORY		1

#define min(a,b) ((a)>(b)?(b):(a))

int sep(int argc, char *argv[])
{	
	if (argc != 7) {
		printf("Usage: %s eigen disk/memory n A E Q\n", argv[0]);
		return -1;
	}
	
	int flag;
	
	if (strcmp(argv[2], "disk") == 0) {
		flag = FLAG_DISK;		
	}
	else if  (strcmp(argv[2], "memory") == 0) {
		flag = FLAG_MEMORY;
	}
	else {
		printf("Usage: %s eigen disk/memory n A E Q\n", argv[0]);
		return -1;
	}
  
	MKL_INT n = (MKL_INT)atoi(argv[3]);
	char *A = argv[4];
	char *E = argv[5];
	char *Q = argv[6];
	
	remove(E);
	remove(Q);
  
	char jobz='V', uplo='U';
	MKL_INT lda = n;	
	MKL_INT info;
	
	//determine
	MKL_INT lwork = -1;
	MKL_INT liwork = -1;
	float lworkopt = 0;
	MKL_INT liworkopt = 0;
	ssyevd(&jobz, &uplo, &n, NULL, &lda, NULL, &lworkopt, &lwork, &liworkopt, &liwork, &info);
	if (info != 0) {
		printf("sgesdd errro\n");
		return -1;
	}
	
	lwork = (MKL_INT)lworkopt;
	liwork = liworkopt;
	
	printf("optimal lwork = %lld, liwork = %lld \n", lwork, liwork);
	
	//calculate space size
	size_t vector_size = n*n*sizeof(float);
	size_t value_size = n*sizeof(float);
	size_t work_size = lwork*sizeof(float);
	size_t iwork_size = liwork*sizeof(MKL_INT);
	
	size_t total_size = vector_size + value_size + work_size + iwork_size;
	printf("total_size = %lld Byte, %.0f MByte\n", total_size, ceil((double)total_size*1.0/1024/1024));
	
	//four spaces
	float *vector = NULL;
	float *value = NULL;
	float *work = NULL;
	MKL_INT *iwork = NULL;
	
	//two in memory
	value = (float *)malloc(value_size);
	iwork = (MKL_INT *)malloc(iwork_size);
	if (value==NULL || iwork==NULL) {
		printf("malloc error\n");
		return -1;
	}
	
	if (flag == FLAG_DISK) {	
		create_file("tmp_work", work_size);
		work = open_vector_file(lwork, "tmp_work");
		if (work == NULL) {
			printf("allocat work error\n");
			return -1;
		}
			
		char cmd[512];
		strcpy(cmd, "cp ");
		strcat(cmd, A);
		strcat(cmd, " ");
		strcat(cmd, Q);
		printf("%s\n", cmd);
		system(cmd);
		vector = open_matrix_file(n, n, Q);
		if (vector == NULL) {
			printf("allocat vector error\n");
			return -1;
		}
	}
	else { //flag == FLAG_MEMORY
		work = (float *)malloc(work_size);
		if (work == NULL) {
			printf("malloc work error\n");
			return -1;
		}
		
		vector = (float *)malloc(vector_size);
		if (vector == NULL) {
			printf("malloc vector error\n");
			return -1;
		}
		
		float *a = open_matrix_file(n, n, A);
		if (a == NULL) {
			printf("open a error\n");
			return -1;
		}
		memcpy(vector, a, vector_size);
		free_matrix(a, n, n);
	}
	
	printf("=== A ===\n");
	print_matrix(vector, n, n);
	
	print_runtime();
	
	//solve
	printf("solve...\n");
	ssyevd(&jobz, &uplo, &n, vector, &lda, value, work, &lwork, iwork, &liwork, &info);
	if (info != 0) {
		printf("ssyevd errro\n");
		return -1;
	}

	print_runtime();
	
	//store values
	create_file(E, value_size);
	float *value_file = open_vector_file(n, E);
	memcpy(value_file, value, value_size);
	free_vector(value_file, n);
	
	if (flag == FLAG_MEMORY) {
		//store vectors
		create_file(Q, vector_size);
		float *vector_file = open_matrix_file(n, n, Q);
		memcpy(vector_file, vector, vector_size);
		free_matrix(vector_file, n, n);
	}
	
	//print
	printf("=== E ===\n");
	print_vector(value, n);

	printf("=== Q ===\n");
	print_matrix(vector, n, n);
		
	//free
	free(value);
	free(iwork);
	
	if (flag == FLAG_DISK) {
		free_vector(work, lwork);
		remove("tmp_work");
				
		free_matrix(vector, n, n);
	}
	else {//flag == FLAG_MEMORY
		free(vector);
		free(work);
	}
	
	return 0;
}		 