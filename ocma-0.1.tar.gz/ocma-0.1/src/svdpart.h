#ifndef __SVD_PART_H__
#define __SVD_PART_H__

int svdpart(int argc, char *argv[]);

#endif