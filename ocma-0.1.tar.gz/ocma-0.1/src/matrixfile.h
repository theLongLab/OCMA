#ifndef __MATRIXFILE_H__
#define __MATRIXFILE_H__

long file_size(char *name);

void create_file(char *name, size_t len);

char *open_file(long n, char *name);
void free_file(char *data, long n);

float *open_vector_file(long n, char *name);
void free_vector(float *data, long n);
void print_vector(float *data, long n);

float *open_matrix_file(long m, long n, char *name);
void free_matrix(float *data, long m, long n);
void print_matrix(float *data, long m, long n);

#endif
