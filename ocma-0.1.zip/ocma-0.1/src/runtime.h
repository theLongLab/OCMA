#ifndef __RUNTIME_H__
#define __RUNTIME_H__

void print_runtime();
 
#endif