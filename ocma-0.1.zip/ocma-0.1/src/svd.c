#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <memory.h>
#include <math.h>

#include <Windows.h>  

#include "mkl.h"

#include "runtime.h"
#include "matrixfile.h"

#define FLAG_DISK 		0
#define FLAG_MEMORY		1

int svd(int argc, char *argv[])
{
	if (argc != 9) {
		printf("Usage: %s singular disk/memory m n A S U V\n", argv[0]);
		return -1;
	}
  
	int flag;
	
	if (strcmp(argv[2], "disk") == 0) {
		flag = FLAG_DISK;		
	}
	else if  (strcmp(argv[2], "memory") == 0) {
		flag = FLAG_MEMORY;
	}
	else {
		printf("Usage: %s singular disk/memory m n A S U V\n", argv[0]);
		return -1;
	}
	
	MKL_INT m = (MKL_INT)atoi(argv[3]);	//row, input
	MKL_INT n = (MKL_INT)atoi(argv[4]);	//col, input
	char *A = argv[5];  				//input
	char *S = argv[6];					//output
	char *U = argv[7];					//output
	char *V = argv[8];					//output
	
	remove(S);
	remove(U);
	remove(V);
	
	char jobz='S';
	MKL_INT lda = m;
	MKL_INT ldu = m;
	MKL_INT ldvt = min(m,n);
	MKL_INT info;
			 
	//determine the length of workspace
	MKL_INT lwork = -1;
	float lworkopt = 0;
	sgesdd(&jobz, &m, &n, NULL, &lda, NULL, NULL, &ldu, NULL, &ldvt,  &lworkopt, &lwork, NULL, &info);	
	if (info != 0) {
		printf("sgesdd error\n");
		return -1;
	}
	
	lwork = (MKL_INT)lworkopt;
	printf("optimal lwork = %ld\n", lwork);
	
	//calculate space size
	size_t a_size = m * n * sizeof(float);
	size_t s_size = min(m,n) * sizeof(float);
	size_t u_size = m * min(m,n) * sizeof(float);
	size_t v_size = min(m,n) * n * sizeof(float);
	size_t work_size = lwork * sizeof(float);
	size_t iwork_size = 8 * min(m,n) * sizeof(MKL_INT);
	
	size_t total_size = a_size + s_size + u_size + v_size + work_size + iwork_size;
	printf("total_size = %lld Byte, %.0f MByte\n", total_size, ceil((double)total_size*1.0/1024/1024));
	
	//six spaces
	float *a = NULL;
	float *s = NULL;
	float *u = NULL;	
	float *v = NULL;
	float *work = NULL;
	MKL_INT *iwork = NULL;
	
	//two in memory
	s =  (float *)malloc(s_size);
	iwork = (MKL_INT *)malloc(iwork_size);
	if (s==NULL || iwork==NULL) {
		printf("malloc error\n");
		return -1;
	}		
	
	if (flag == FLAG_DISK) {		
		create_file("tmp_AT", a_size);
		a = open_matrix_file(m, n, "tmp_AT");
		if (a == NULL) {
			printf("allocate a error\n");
			return -1;
		}
		
		create_file(U, u_size);
		u = open_matrix_file(m, min(m,n), U);
		if (u == NULL) {
			printf("allocate u error\n");
			return -1;
		}
		
		create_file(V, v_size);
		v = open_matrix_file(min(m,n), n, V);
		if (v == NULL) {
			printf("allocate v error\n");
			return -1;
		}	

		create_file("tmp_work", work_size);
		work = open_vector_file(lwork, "tmp_work");
		if (work == NULL) {
			printf("allocate work error\n");
			return -1;
		}
	}
	else {//flag == FLAG_MEMORY
		a = (float *)malloc(a_size);
		if (a == NULL) {
			printf("malloc a error\n");
			return -1;
		}
		
		u = (float *)malloc(u_size);	
		if (u == NULL) {
			printf("malloc u error\n");
			return -1;
		}
		
		v = (float *)malloc(v_size);
		if (v == NULL) {
			printf("malloc v error\n");
			return -1;
		}
		
		work = (float *)malloc(work_size);
		if (work == NULL) {
			printf("malloc work error\n");
			return -1;
		}
	}
		
	//transpose a
	float *aa = open_matrix_file(m, n, A);
	if (aa == NULL) {
		printf("open aa error\n");
		return -1;
	}
	printf("=== A ===\n");
	print_matrix(aa, m, n);		
	mkl_somatcopy('R', 'T', m, n, 1.0, aa, n, a, m);
	free_matrix(aa, m, n);	
	
	print_runtime();
	
	//solve	
	printf("solve...\n");
	sgesdd(&jobz, &m, &n, a, &lda, s, u, &ldu, v, &ldvt,  work, &lwork, iwork, &info);	
	if (info != 0) {
		printf("sgesdd errro\n");
		return -1;
	}

	print_runtime();
	
	//transpose u
	mkl_simatcopy('R', 'T', min(m,n), m, 1.0, u, m, min(m,n));
	//transpose v
	//mkl_simatcopy('R', 'T', n, min(m,n), 1.0, v, min(m,n), n);
	
	//store s
	create_file(S, s_size);
	float *s_file = open_vector_file(min(m,n), S);
	if (s_file == NULL) {
		printf("allocat s_file error\n");
		return -1;
	}
	memcpy(s_file, s, s_size);
	free_vector(s_file, min(m,n));
	
	if (flag == FLAG_MEMORY) {
		//store u
		create_file(U, u_size);
		float *u_file = open_matrix_file(m, min(m,n), U);
		if (u_file == NULL) {
			printf("allocat u_file error\n");
			return -1;
		}
		memcpy(u_file, u, u_size);
		free_matrix(u_file, m, min(m,n));
		
		//store v
		create_file(V, v_size);
		float *v_file = open_matrix_file(min(m,n), n, V);
		if (v_file == NULL) {
			printf("allocat v_file error\n");
			return -1;
		}
		memcpy(v_file, v, v_size);
		free_matrix(v_file, min(m,n), n);
	}
	
	//print
	printf("=== S ===\n");
	print_vector(s, min(m,n));

	printf("=== U ===\n");
	print_matrix(u, m, min(m,n));
	
	printf("=== V' ===\n");
	print_matrix(v, n, min(m,n));
		
	//free space
	free(s);
	free(iwork);
	
	if (flag == FLAG_DISK) {
		free_matrix(a, m, n);
		remove("tmp_AT");
		
		free_vector(work, lwork);
		remove("tmp_work");
			
		free_matrix(u, m, min(m,n));
		free_matrix(v, min(m,n), n);	
	}	
	else {//flag == FLAG_MEMORY
		free(a);
		free(u);
		free(v);
		free(work);
	}
	
	return 0;
}			 