#ifndef __MATRIXFILE_H__
#define __MATRIXFILE_H__

LONGLONG file_size(char *name);

void create_file(char *name, size_t len);

char *open_file(LONGLONG n, char *name);
void free_file(char *data, LONGLONG n);

float *open_vector_file(LONGLONG n, char *name);
void free_vector(float *data, LONGLONG n);
void print_vector(float *data, LONGLONG n);

float *open_matrix_file(LONGLONG m, LONGLONG n, char *name);
void free_matrix(float *data, LONGLONG m, LONGLONG n);
void print_matrix(float *data, LONGLONG m, LONGLONG n);

#endif
