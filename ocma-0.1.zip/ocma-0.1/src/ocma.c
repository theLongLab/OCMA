#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "sep.h"
#include "svd.h"
#include "svdpart.h"

int main(int argc, char *argv[]) 
{
	// printf("sizeof(size_t) = %d\n", sizeof(size_t));
	// printf("sizeof(MKL_INT) = %d\n", sizeof(MKL_INT));
	// printf("sizeof(long) = %d\n", sizeof(long));
	// printf("sizeof(LONGLONG) = %d\n", sizeof(LONGLONG));
	
	if ((argc!=9) && (argc!=7) && (argc!=10)) {
		printf("Usage: %s eigen disk/memory n A E Q\n", argv[0]);
		printf("or\n");
		printf("Usage: %s singular disk/memory m n A S U V\n", argv[0]);
		printf("or\n");
		printf("Usage: %s singularpart disk/memory m n k A S U V\n", argv[0]);
		printf("or\n");
		printf("Usage: %s format txt2bin/bin2txt m n A B\n", argv[0]);
		return -1;
	}
	
	if (strcmp(argv[1], "eigen")==0) {
		sep(argc, argv);
	}
	else if (strcmp(argv[1], "singular")==0) {
		svd(argc, argv);
	}
	else if (strcmp(argv[1], "singularpart")==0) {
		svdpart(argc, argv);
	}
	else if (strcmp(argv[1], "format")==0) {
		format(argc, argv);
	}
	else {
		printf("Usage: %s eigen disk/memory n A E Q\n", argv[0]);
		printf("or\n");
		printf("Usage: %s singular disk/memory m n A S U V\n", argv[0]);
		printf("or\n");
		printf("Usage: %s singularpart disk/memory m n k A S U V\n", argv[0]);
		printf("or\n");
		printf("Usage: %s format txt2bin/bin2txt m n A B\n", argv[0]);
		return -1;
	}
	
	return 0;
}