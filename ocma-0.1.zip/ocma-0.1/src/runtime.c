#include<stdio.h>
#include<time.h>
#include<stdlib.h>

void print_runtime() 
{
	static int first = 1;
	clock_t starttime=0, endtime=0;
	double interval_seconds = 0;
	double interval_hours = 0;
		
	if (first == 1) {
		first = 0;
		starttime = clock();
		printf("=== begin to record time ===\n");
		return;
	}
	
	endtime = clock();
	interval_seconds = (double)(endtime - starttime) / 1000;
	interval_hours = interval_seconds / 3600;
	
	printf("=== runtime = %.1f seconds ===", interval_seconds);
	printf("  ||  ");
	printf("=== runtime = %.2f hours ===\n", interval_hours);
}