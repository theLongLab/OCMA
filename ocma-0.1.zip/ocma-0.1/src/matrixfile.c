#include <stdlib.h>
#include <stdio.h>

#include <Windows.h>   

#define PRINT_LIMIT 5

/*
typedef union _LARGE_INTEGER {
  struct {
    DWORD LowPart;
    LONG  HighPart;
  };
  struct {
    DWORD LowPart;
    LONG  HighPart;
  } u;
  LONGLONG QuadPart;
} LARGE_INTEGER, *PLARGE_INTEGER;

HANDLE WINAPI CreateFile(
  _In_     LPCTSTR               lpFileName,
  _In_     DWORD                 dwDesiredAccess,
  _In_     DWORD                 dwShareMode,
  _In_opt_ LPSECURITY_ATTRIBUTES lpSecurityAttributes,
  _In_     DWORD                 dwCreationDisposition,
  _In_     DWORD                 dwFlagsAndAttributes,
  _In_opt_ HANDLE                hTemplateFile
);
https://msdn.microsoft.com/en-us/library/windows/desktop/aa363858(v=vs.85).aspx

HANDLE WINAPI CreateFileMapping(
  _In_     HANDLE                hFile,
  _In_opt_ LPSECURITY_ATTRIBUTES lpAttributes,
  _In_     DWORD                 flProtect,
  _In_     DWORD                 dwMaximumSizeHigh,
  _In_     DWORD                 dwMaximumSizeLow,
  _In_opt_ LPCTSTR               lpName
);
https://msdn.microsoft.com/en-us/library/aa366537(VS.85).aspx

LPVOID WINAPI MapViewOfFile(
  _In_ HANDLE hFileMappingObject,
  _In_ DWORD  dwDesiredAccess,
  _In_ DWORD  dwFileOffsetHigh,
  _In_ DWORD  dwFileOffsetLow,
  _In_ SIZE_T dwNumberOfBytesToMap
);
https://msdn.microsoft.com/en-us/library/aa366761(VS.85).aspx

UnmapViewOfFile(mappedFileAddress);
CloseHandle(fileMappingObject);
CloseHandle(dumpFileDescriptor);
unlink(mmFileName);
*/

///////////////////////////////////////////////////////////////////////////

LONGLONG file_size(char *name)
{
	FILE *fp;
	LONGLONG len;
    fp=fopen(name, "r");
    fseek(fp, 0L, SEEK_END);
    len = (LONGLONG)ftell(fp);
	fclose(fp);
	return len;
}

///////////////////////////////////////////////////////////////////////////

void create_file(char *name, size_t len)
{
	FILE *fp;
	float f = 0;
	fp = fopen(name, "w+");
	fseek(fp, len-sizeof(float), SEEK_END);
	fwrite(&f, sizeof(float), 1, fp);
	fclose(fp);
}

///////////////////////////////////////////////////////////////////////////
//normal file

char *open_file(LONGLONG n, char *name)
{
	LARGE_INTEGER size;
	size.QuadPart = n;
	
	HANDLE hFile = CreateFile(name,
                       GENERIC_READ | GENERIC_WRITE,
                       FILE_SHARE_READ | FILE_SHARE_WRITE,
                       NULL,
                       OPEN_EXISTING,
                       FILE_ATTRIBUTE_NORMAL,
                       NULL);
	if (hFile == INVALID_HANDLE_VALUE) {
		printf("CreateFile error\n");
		return NULL;
	}
	
	HANDLE hFileMapping = CreateFileMapping(hFile,
                       NULL,
                       PAGE_READWRITE,
                       size.HighPart,
                       size.LowPart,
                       NULL);
	if (hFileMapping == NULL) {
		printf("CreateFileMapping error\n");
		return NULL;
	}	

	char* data = (char *)MapViewOfFile(hFileMapping,
                       FILE_MAP_ALL_ACCESS,
                       0,
                       0,
                       size.QuadPart);
	if (data == NULL) {
		printf("MapViewOfFile error\n");
		return NULL;
	}				   
	
	return data;
}


void free_file(char *data, LONGLONG n)
{
	UnmapViewOfFile(data);
}

///////////////////////////////////////////////////////////////////////////
//vector

float *open_vector_file(LONGLONG n, char *name)
{
	LARGE_INTEGER size;
	size.QuadPart = n*sizeof(float);
	
	HANDLE hFile = CreateFile(name,
                       GENERIC_READ | GENERIC_WRITE,
                       FILE_SHARE_READ | FILE_SHARE_WRITE,
                       NULL,
                       OPEN_EXISTING,
                       FILE_ATTRIBUTE_NORMAL,
                       NULL);
	if (hFile == INVALID_HANDLE_VALUE) {
		printf("CreateFile error\n");
		return NULL;
	}
	
	HANDLE hFileMapping = CreateFileMapping(hFile,
                       NULL,
                       PAGE_READWRITE,
                       size.HighPart,
                       size.LowPart,
                       NULL);
	if (hFileMapping == NULL) {
		printf("CreateFileMapping error\n");
		return NULL;
	}	

	float* data = (float *)MapViewOfFile(hFileMapping,
                       FILE_MAP_ALL_ACCESS,
                       0,
                       0,
                       size.QuadPart);
	if (data == NULL) {
		printf("MapViewOfFile error\n");
		return NULL;
	}				   
	
	return data;
}


void free_vector(float *data, LONGLONG n)
{
	UnmapViewOfFile(data);
}

void print_vector(float *data, LONGLONG n)
{
	LONGLONG j;
	
	if (n <= 2*PRINT_LIMIT) {
		for (j=0; j<n; j++) {
			printf("%+e ", data[j]);
		}			
		printf("\n");		
		return;
	}
	
	//else
	for (j=0; j<PRINT_LIMIT; j++) {
		printf("%+e ", data[j]);
	}	
	printf("... ");
	for (j=n-PRINT_LIMIT; j<n; j++) {
		printf("%+e ", data[j]);
	}
	printf("\n");  
}

///////////////////////////////////////////////////////////////////////////
//matrix

float *open_matrix_file(LONGLONG m, LONGLONG n, char *name)
{
	LONGLONG mn = (LONGLONG)m * (LONGLONG)n;
	
	LARGE_INTEGER size;
	size.QuadPart = mn*sizeof(float);
	
	HANDLE hFile = CreateFile(name,
                       GENERIC_READ | GENERIC_WRITE,
                       FILE_SHARE_READ | FILE_SHARE_WRITE,
                       NULL,
                       OPEN_EXISTING,
                       FILE_ATTRIBUTE_NORMAL,
                       NULL);
	if (hFile == INVALID_HANDLE_VALUE) {
		printf("CreateFile error\n");
		return NULL;
	}
	
	HANDLE hFileMapping = CreateFileMapping(hFile,
                       NULL,
                       PAGE_READWRITE,
                       size.HighPart,
                       size.LowPart,
                       NULL);
	if (hFileMapping == NULL) {
		printf("CreateFileMapping error\n");
		return NULL;
	}	

	float* data = (float *)MapViewOfFile(hFileMapping,
                       FILE_MAP_ALL_ACCESS,
                       0,
                       0,
                       size.QuadPart);
	if (data == NULL) {
		printf("MapViewOfFile error\n");
		return NULL;
	}			
		
	return data;
}


void free_matrix(float *data, LONGLONG m, LONGLONG n)
{
	UnmapViewOfFile(data);
}

void print_matrix(float *data, LONGLONG m, LONGLONG n)
{
	LONGLONG i;
	LONGLONG in;
	
	if (m <= 2*PRINT_LIMIT) {
		for (i=0; i<m; i++) {
			print_vector(&data[i*n], n);
		}			
		return;
	}
	
	//else
	for (i=0; i<PRINT_LIMIT; i++) {
		in = (LONGLONG)i * (LONGLONG)n;
		print_vector(&data[in], n);
	}	
	printf("...\n");
	for (i=m-PRINT_LIMIT; i<m; i++) {
		in = (LONGLONG)i * (LONGLONG)n;
		print_vector(&data[in], n);
	}
}