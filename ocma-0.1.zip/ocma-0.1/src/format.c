#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <memory.h>
#include <math.h>

#include <Windows.h>
  
#include "mkl.h"

#include "runtime.h"
#include "matrixfile.h"


int txt2bin(int argc, char *argv[])
{	
	MKL_INT m = (MKL_INT)atoi(argv[3]);
	MKL_INT n = (MKL_INT)atoi(argv[4]);
	char *txtA = argv[5];
	char *binA = argv[6];
	
	remove(binA);
  
	LONGLONG len = file_size(txtA);
	char *txtData = open_file(len, txtA);
	if (txtData == NULL) {
		printf("open txtA error\n");
		return -1;
	}
	
	create_file(binA, m*n*sizeof(float));
	float *binData = open_matrix_file(m, n, binA);
	if (binData == NULL) {
		printf("open binA error\n");
		return -1;
	}
	
	char *p = txtData;
	char *q = NULL;
	LONGLONG i = 0;
	LONGLONG count = m*n;
	
	//skip blank
	while (1) {
		if ((*p>='0' && *p<='9') || (*p=='-' || *p=='+'))
			break;
		p++;
	}
	
	//first one
	binData[0] = (float)atof(p);
	//printf("%f\n", binData[0]);
	p++;
	
	int flag = 0;
	
	//count-1
	for (i=1; i<count; i++) {
		flag = 0;
		
		//find the first digital or sign
		while (1) {
			q = p - 1;
			if (((*p>='0' && *p<='9') || (*p=='-' || *p=='+'))
					&& (*q==' ' || *q=='\r' || *q=='\n')) {
				flag = 1;
				break;
			}
			p++;			
			if (p-txtData >= len) {
				flag = 0;
				break;
			}
		}
		
		if (flag == 1) {
			binData[i] = (float)atof(p);
			//printf("%f\n", binData[i]);			
		}

		p++;
		if (p-txtData >= len) {
			break;
		}		
	}
	
	if (i != count) {
		printf("count is wrong\n");
	}
	
	free_file(txtData, len);
	free_matrix(binData, m, n);
	
	return 0;
}


int bin2txt(int argc, char *argv[])
{	
	MKL_INT m = (MKL_INT)atoi(argv[3]);
	MKL_INT n = (MKL_INT)atoi(argv[4]);
	char *binA = argv[5];
	char *txtA = argv[6];
	
	remove(txtA);
  
	float *binData = open_matrix_file(m, n, binA);
	if (binData == NULL) {
		printf("open binA error\n");
		return -1;
	}
	
	FILE *fp;
	fp = fopen(txtA, "w");
	
	LONGLONG i;
	LONGLONG j;
	
	for (i=0; i<m; i++) {
		for (j=0; j<n; j++) {
			fprintf(fp, "%f", binData[i*n + j]);
			
			if (j==n-1) {
				fprintf(fp, "\n");
			}
			else {
				fprintf(fp, " ");
			}
		}
	}
	
	free_matrix(binData, m, n);
	fclose(fp);
	
	return 0;
}


int format(int argc, char *argv[])
{
	if (argc != 7) {
		printf("Usage: %s format txt2bin/bin2txt m n A B\n", argv[0]);
		return -1;
	}
	
	if (strcmp(argv[2], "txt2bin") == 0) {
		return txt2bin(argc, argv);		
	}
	else if  (strcmp(argv[2], "bin2txt") == 0) {
		return bin2txt(argc, argv);
	}
	else {
		printf("Usage: %s format txt2bin/bin2txt m n A B\n", argv[0]);
		return -1;
	}
}	